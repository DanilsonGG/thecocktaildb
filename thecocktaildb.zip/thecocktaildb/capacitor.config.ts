import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.starter',
  appName: 'thecocktaildb',
  webDir: 'dist'
};

export default config;
